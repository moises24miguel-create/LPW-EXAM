<?php
// ============================================
// config.php - Database Configuration
// ============================================

define('DB_HOST', 'localhost');
define('DB_USER', 'root');        // Change to your MySQL username
define('DB_PASS', '');            // Change to your MySQL password
define('DB_NAME', 'student_db');

define('UPLOAD_DIR', __DIR__ . '/uploads/');
define('UPLOAD_URL', 'uploads/');

// Connect to MySQL using mysqli
try {
    $conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

    if (!$conn) {
        throw new Exception("Connection failed: " . mysqli_connect_error());
    }

    // Set charset
    mysqli_set_charset($conn, 'utf8mb4');

} catch (Exception $e) {
    http_response_code(500);
    die("
    <!DOCTYPE html>
    <html>
    <head>
        <title>Database Error</title>
        <style>
            body { font-family: monospace; background: #0f0f0f; color: #ff4444; 
                   display: flex; align-items: center; justify-content: center; 
                   min-height: 100vh; margin: 0; }
            .error-box { background: #1a0000; border: 1px solid #ff4444; 
                         padding: 2rem; border-radius: 8px; max-width: 500px; }
            h2 { margin-top: 0; }
        </style>
    </head>
    <body>
        <div class='error-box'>
            <h2>⚠ Database Connection Error</h2>
            <p>" . htmlspecialchars($e->getMessage()) . "</p>
            <p>Please check your database credentials in <code>config.php</code>.</p>
        </div>
    </body>
    </html>
    ");
}
?>

<?php
// ============================================
// login.php - Admin Login Page
// ============================================
session_start();

// Already logged in? Go to dashboard
if (isset($_SESSION['admin_id'])) {
    header("Location: index.php");
    exit;
}

require_once 'config.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($username) || empty($password)) {
        $error = 'Please enter both username and password.';
    } else {
        $stmt = mysqli_prepare($conn, "SELECT id, username, password FROM admin_users WHERE username = ?");
        mysqli_stmt_bind_param($stmt, "s", $username);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $admin = mysqli_fetch_assoc($result);
        mysqli_stmt_close($stmt);

        if ($admin && password_verify($password, $admin['password'])) {
            session_regenerate_id(true);
            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['admin_username'] = $admin['username'];
            header("Location: index.php");
            exit;
        } else {
            $error = 'Invalid username or password.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login — Student Record System</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="style.css">
    <style>
        body.login-page {
            background: var(--bg-deep);
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
        }
        .login-card {
            background: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: 20px;
            padding: 3rem 2.5rem;
            width: 100%;
            max-width: 420px;
            box-shadow: 0 25px 60px rgba(0,0,0,0.4);
            animation: fadeInUp 0.6s ease both;
        }
        .login-logo {
            width: 64px;
            height: 64px;
            background: var(--accent-gradient);
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.8rem;
            margin: 0 auto 1.5rem;
        }
        .login-title { 
            font-family: var(--font-display);
            font-size: 1.8rem; 
            font-weight: 700;
            color: var(--text-primary);
            text-align: center;
        }
        .login-subtitle {
            color: var(--text-muted);
            text-align: center;
            font-size: 0.875rem;
            margin-bottom: 2rem;
        }
        .form-floating label { color: var(--text-muted); }
        .form-floating .form-control {
            background: var(--input-bg);
            border: 1px solid var(--border-color);
            color: var(--text-primary);
            border-radius: 12px;
            height: 58px;
        }
        .form-floating .form-control:focus {
            background: var(--input-bg);
            border-color: var(--accent);
            color: var(--text-primary);
            box-shadow: 0 0 0 3px rgba(99,102,241,0.15);
        }
        .btn-login {
            background: var(--accent-gradient);
            border: none;
            border-radius: 12px;
            height: 52px;
            font-weight: 600;
            font-size: 1rem;
            letter-spacing: 0.5px;
            transition: all 0.3s ease;
        }
        .btn-login:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(99,102,241,0.4); }
        .default-creds {
            background: rgba(99,102,241,0.1);
            border: 1px solid rgba(99,102,241,0.3);
            border-radius: 10px;
            padding: 0.75rem 1rem;
            font-size: 0.8rem;
            color: var(--text-muted);
            margin-top: 1.5rem;
            text-align: center;
        }
    </style>
</head>
<body class="login-page">
    <div class="login-card">
        <div class="login-logo">🎓</div>
        <h1 class="login-title">Welcome Back</h1>
        <p class="login-subtitle">Student Record Management System</p>

        <?php if ($error): ?>
        <div class="alert alert-danger d-flex align-items-center gap-2 rounded-3" role="alert">
            <i class="bi bi-exclamation-circle-fill"></i>
            <?= htmlspecialchars($error) ?>
        </div>
        <?php endif; ?>

        <form method="POST" action="login.php">
            <div class="form-floating mb-3">
                <input type="text" class="form-control" id="username" name="username"
                       placeholder="Username" value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" required>
                <label for="username"><i class="bi bi-person me-1"></i>Username</label>
            </div>
            <div class="form-floating mb-4">
                <input type="password" class="form-control" id="password" name="password"
                       placeholder="Password" required>
                <label for="password"><i class="bi bi-lock me-1"></i>Password</label>
            </div>
            <button type="submit" class="btn btn-primary btn-login w-100">
                Sign In <i class="bi bi-arrow-right ms-2"></i>
            </button>
        </form>

        <div class="default-creds">
            <i class="bi bi-info-circle me-1"></i>
            Default credentials: <strong>admin</strong> / <strong>admin123</strong>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
// ============================================
// index.php - Main Dashboard
// ============================================
require_once 'auth_check.php';
require_once 'config.php';

// Fetch stats
$total_students = 0;
$recent_students = 0;

$res = mysqli_query($conn, "SELECT COUNT(*) as total FROM students");
if ($res) $total_students = mysqli_fetch_assoc($res)['total'];

$res2 = mysqli_query($conn, "SELECT COUNT(*) as recent FROM students WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)");
if ($res2) $recent_students = mysqli_fetch_assoc($res2)['recent'];

$res3 = mysqli_query($conn, "SELECT COUNT(DISTINCT course) as total_courses FROM students");
$total_courses = $res3 ? mysqli_fetch_assoc($res3)['total_courses'] : 0;

$admin_name = $_SESSION['admin_username'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard — Student Record System</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<!-- ── Navbar ── -->
<header>
    <nav class="navbar navbar-expand-lg navbar-custom">
        <div class="container-fluid px-4">
            <a class="navbar-brand d-flex align-items-center" href="index.php">
                <span class="navbar-icon">🎓</span>
                <span class="navbar-brand-text">Student<span>RMS</span></span>
            </a>

            <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navMenu">
                <ul class="navbar-nav me-auto gap-1 ms-3">
                    <li class="nav-item">
                        <a class="nav-link-custom active" href="index.php">
                            <i class="bi bi-grid-1x2"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link-custom" href="view_students.php">
                            <i class="bi bi-people"></i> Students
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link-custom" href="add_student.php">
                            <i class="bi bi-person-plus"></i> Add Student
                        </a>
                    </li>
                </ul>

                <div class="d-flex align-items-center gap-3">
                    <span class="d-none d-md-flex align-items-center gap-2" style="color:var(--text-muted);font-size:.8rem;">
                        <i class="bi bi-person-circle" style="color:var(--accent-light)"></i>
                        <?= htmlspecialchars($admin_name) ?>
                    </span>
                    <a href="logout.php" class="btn-logout btn">
                        <i class="bi bi-box-arrow-right me-1"></i>Logout
                    </a>
                </div>
            </div>
        </div>
    </nav>
</header>

<!-- ── Main Content ── -->
<main>
    <div class="page-wrapper main-content">
        <div class="container-fluid px-4">

            <!-- Page Header -->
            <div class="page-header d-flex align-items-center justify-content-between">
                <div>
                    <h1 class="page-title">Dashboard</h1>
                    <p class="page-subtitle">Welcome back, <strong style="color:var(--accent-light)"><?= htmlspecialchars($admin_name) ?></strong></p>
                </div>
                <a href="add_student.php" class="btn-accent">
                    <i class="bi bi-plus-lg"></i> Add Student
                </a>
            </div>

            <!-- Stats Row -->
            <div class="row g-4 mb-4">
                <div class="col-sm-6 col-xl-3">
                    <div class="stat-card" style="animation-delay:0.1s">
                        <div class="stat-icon purple">
                            <i class="bi bi-people-fill"></i>
                        </div>
                        <div class="stat-number"><?= $total_students ?></div>
                        <div class="stat-label">Total Students</div>
                    </div>
                </div>
                <div class="col-sm-6 col-xl-3">
                    <div class="stat-card" style="animation-delay:0.2s">
                        <div class="stat-icon green">
                            <i class="bi bi-person-plus-fill"></i>
                        </div>
                        <div class="stat-number"><?= $recent_students ?></div>
                        <div class="stat-label">New This Month</div>
                    </div>
                </div>
                <div class="col-sm-6 col-xl-3">
                    <div class="stat-card" style="animation-delay:0.3s">
                        <div class="stat-icon yellow">
                            <i class="bi bi-mortarboard-fill"></i>
                        </div>
                        <div class="stat-number"><?= $total_courses ?></div>
                        <div class="stat-label">Courses Enrolled</div>
                    </div>
                </div>
                <div class="col-sm-6 col-xl-3">
                    <div class="stat-card" style="animation-delay:0.4s">
                        <div class="stat-icon blue">
                            <i class="bi bi-shield-check-fill"></i>
                        </div>
                        <div class="stat-number">1</div>
                        <div class="stat-label">Active Admin</div>
                    </div>
                </div>
            </div>

            <!-- Recent Students Quick View -->
            <div class="row g-4">
                <div class="col-lg-8">
                    <div class="content-card">
                        <div class="card-header-custom">
                            <span class="card-title-custom">
                                <i class="bi bi-clock-history" style="color:var(--accent-light)"></i>
                                Recent Students
                            </span>
                            <a href="view_students.php" class="btn-accent" style="font-size:.8rem;padding:.4rem 1rem">
                                View All <i class="bi bi-arrow-right"></i>
                            </a>
                        </div>
                        <div class="card-body-custom p-0">
                            <table class="table-custom w-100">
                                <thead>
                                    <tr>
                                        <th>Photo</th>
                                        <th>Name</th>
                                        <th>Course</th>
                                        <th>Enrolled</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
                                $recent = mysqli_query($conn, "SELECT * FROM students ORDER BY created_at DESC LIMIT 5");
                                if ($recent && mysqli_num_rows($recent) > 0):
                                    while ($s = mysqli_fetch_assoc($recent)):
                                ?>
                                    <tr>
                                        <td>
                                            <img src="<?= htmlspecialchars(UPLOAD_URL . ($s['photo'] ?: 'default.png')) ?>"
                                                 alt="" class="student-thumb">
                                        </td>
                                        <td class="student-name"><?= htmlspecialchars($s['name']) ?></td>
                                        <td><span class="badge-course"><?= htmlspecialchars($s['course']) ?></span></td>
                                        <td style="color:var(--text-muted);font-size:.8rem">
                                            <?= date('d M Y', strtotime($s['created_at'])) ?>
                                        </td>
                                    </tr>
                                <?php endwhile; else: ?>
                                    <tr>
                                        <td colspan="4">
                                            <div class="empty-state py-4">
                                                <div class="empty-state-icon">📋</div>
                                                <p>No students yet. <a href="add_student.php" style="color:var(--accent-light)">Add one now</a></p>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="col-lg-4">
                    <div class="content-card h-100">
                        <div class="card-header-custom">
                            <span class="card-title-custom">
                                <i class="bi bi-lightning-fill" style="color:#fbbf24"></i>
                                Quick Actions
                            </span>
                        </div>
                        <div class="card-body-custom d-flex flex-column gap-3">
                            <a href="add_student.php" class="d-flex align-items-center gap-3 text-decoration-none p-3 rounded-3"
                               style="background:rgba(99,102,241,0.08);border:1px solid rgba(99,102,241,0.15);transition:all .2s"
                               onmouseover="this.style.background='rgba(99,102,241,0.15)'"
                               onmouseout="this.style.background='rgba(99,102,241,0.08)'">
                                <div class="stat-icon purple mb-0" style="width:40px;height:40px;font-size:1.1rem">
                                    <i class="bi bi-person-plus-fill"></i>
                                </div>
                                <div>
                                    <div style="font-weight:600;font-size:.9rem;color:var(--text-primary)">Add New Student</div>
                                    <div style="font-size:.75rem;color:var(--text-muted)">Register a student record</div>
                                </div>
                            </a>
                            <a href="view_students.php" class="d-flex align-items-center gap-3 text-decoration-none p-3 rounded-3"
                               style="background:rgba(16,185,129,0.08);border:1px solid rgba(16,185,129,0.15);transition:all .2s"
                               onmouseover="this.style.background='rgba(16,185,129,0.15)'"
                               onmouseout="this.style.background='rgba(16,185,129,0.08)'">
                                <div class="stat-icon green mb-0" style="width:40px;height:40px;font-size:1.1rem">
                                    <i class="bi bi-table"></i>
                                </div>
                                <div>
                                    <div style="font-weight:600;font-size:.9rem;color:var(--text-primary)">View All Students</div>
                                    <div style="font-size:.75rem;color:var(--text-muted)">Browse, search & manage</div>
                                </div>
                            </a>
                            <a href="logout.php" class="d-flex align-items-center gap-3 text-decoration-none p-3 rounded-3"
                               style="background:rgba(239,68,68,0.08);border:1px solid rgba(239,68,68,0.15);transition:all .2s"
                               onmouseover="this.style.background='rgba(239,68,68,0.15)'"
                               onmouseout="this.style.background='rgba(239,68,68,0.08)'">
                                <div class="stat-icon mb-0" style="width:40px;height:40px;font-size:1.1rem;background:rgba(239,68,68,0.12);color:#fca5a5">
                                    <i class="bi bi-box-arrow-right"></i>
                                </div>
                                <div>
                                    <div style="font-weight:600;font-size:.9rem;color:#fca5a5">Logout</div>
                                    <div style="font-size:.75rem;color:var(--text-muted)">End your session</div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</main>

<!-- ── Footer ── -->
<footer class="site-footer">
    <p>© <?= date('Y') ?> Student Record Management System · Built with PHP & MySQL</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
// ============================================
// add_student.php - Add Student with Validation
// ============================================
require_once 'auth_check.php';
require_once 'config.php';

$success = '';
$error   = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // ── Server-side validation
    $name   = trim($_POST['name']   ?? '');
    $email  = trim($_POST['email']  ?? '');
    $phone  = trim($_POST['phone']  ?? '');
    $course = trim($_POST['course'] ?? '');
    $dob    = $_POST['dob'] ?? '';
    $errors = [];

    if (!preg_match('/^[A-Za-z\s]{3,}$/', $name))
        $errors[] = "Invalid name.";
    if (!filter_var($email, FILTER_VALIDATE_EMAIL))
        $errors[] = "Invalid email.";
    if (!preg_match('/^\d{10}$/', $phone))
        $errors[] = "Phone must be 10 digits.";
    if (empty($course))
        $errors[] = "Course is required.";
    if (empty($dob) || strtotime($dob) > time())
        $errors[] = "Date of birth must not be a future date.";

    // Handle photo upload
    $photo_name = 'default.png';
    if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
        $ext = strtolower(pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, ['jpg', 'jpeg', 'png'])) {
            $errors[] = "Photo must be .jpg or .png.";
        } else {
            $photo_name = uniqid('stu_', true) . '.' . $ext;
            $dest = UPLOAD_DIR . $photo_name;
            if (!move_uploaded_file($_FILES['photo']['tmp_name'], $dest)) {
                $errors[] = "Photo upload failed.";
                $photo_name = 'default.png';
            }
        }
    }

    if (empty($errors)) {
        $stmt = mysqli_prepare($conn,
            "INSERT INTO students (name, email, phone, course, dob, photo) VALUES (?, ?, ?, ?, ?, ?)");
        mysqli_stmt_bind_param($stmt, "ssssss", $name, $email, $phone, $course, $dob, $photo_name);
        if (mysqli_stmt_execute($stmt)) {
            $success = "Student <strong>" . htmlspecialchars($name) . "</strong> added successfully!";
        } else {
            if (mysqli_errno($conn) == 1062) {
                $error = "A student with that email already exists.";
            } else {
                $error = "Database error: " . mysqli_error($conn);
            }
        }
        mysqli_stmt_close($stmt);
    } else {
        $error = implode('<br>', $errors);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Student — Student Record System</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<!-- Navbar -->
<header>
    <nav class="navbar navbar-expand-lg navbar-custom">
        <div class="container-fluid px-4">
            <a class="navbar-brand d-flex align-items-center" href="index.php">
                <span class="navbar-icon">🎓</span>
                <span class="navbar-brand-text">Student<span>RMS</span></span>
            </a>
            <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navMenu">
                <ul class="navbar-nav me-auto gap-1 ms-3">
                    <li class="nav-item"><a class="nav-link-custom" href="index.php"><i class="bi bi-grid-1x2"></i> Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link-custom" href="view_students.php"><i class="bi bi-people"></i> Students</a></li>
                    <li class="nav-item"><a class="nav-link-custom active" href="add_student.php"><i class="bi bi-person-plus"></i> Add Student</a></li>
                </ul>
                <a href="logout.php" class="btn-logout btn"><i class="bi bi-box-arrow-right me-1"></i>Logout</a>
            </div>
        </div>
    </nav>
</header>

<main>
<div class="page-wrapper main-content">
<div class="container-fluid px-4">

    <div class="page-header">
        <h1 class="page-title">Add New Student</h1>
        <p class="page-subtitle">Fill in the form below to register a new student</p>
    </div>

    <?php if ($success): ?>
    <div class="alert-custom alert-success-custom mb-4">
        <i class="bi bi-check-circle-fill"></i>
        <?= $success ?>
        <a href="view_students.php" class="ms-2" style="color:inherit;text-decoration:underline">View All Students</a>
    </div>
    <?php endif; ?>

    <?php if ($error): ?>
    <div class="alert-custom alert-danger-custom mb-4">
        <i class="bi bi-exclamation-circle-fill"></i>
        <?= $error ?>
    </div>
    <?php endif; ?>

    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="content-card">
                <div class="card-header-custom">
                    <span class="card-title-custom">
                        <i class="bi bi-person-badge" style="color:var(--accent-light)"></i>
                        Student Information
                    </span>
                </div>
                <div class="card-body-custom">
                    <form id="addStudentForm" method="POST" action="add_student.php" enctype="multipart/form-data" novalidate>
                        <div class="row g-4">

                            <!-- Name -->
                            <div class="col-md-6">
                                <label class="form-label-custom" for="name">Full Name</label>
                                <input type="text" id="name" name="name" class="form-control-custom"
                                       placeholder="e.g. Arjun Sharma"
                                       value="<?= htmlspecialchars($_POST['name'] ?? '') ?>">
                                <div class="field-feedback" id="name-feedback"></div>
                            </div>

                            <!-- Email -->
                            <div class="col-md-6">
                                <label class="form-label-custom" for="email">Email Address</label>
                                <input type="email" id="email" name="email" class="form-control-custom"
                                       placeholder="e.g. arjun@example.com"
                                       value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
                                <div class="field-feedback" id="email-feedback"></div>
                            </div>

                            <!-- Phone -->
                            <div class="col-md-6">
                                <label class="form-label-custom" for="phone">Phone Number</label>
                                <input type="tel" id="phone" name="phone" class="form-control-custom"
                                       placeholder="10-digit number"
                                       value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>">
                                <div class="field-feedback" id="phone-feedback"></div>
                            </div>

                            <!-- Course -->
                            <div class="col-md-6">
                                <label class="form-label-custom" for="course">Course</label>
                                <input type="text" id="course" name="course" class="form-control-custom"
                                       placeholder="e.g. Computer Science"
                                       value="<?= htmlspecialchars($_POST['course'] ?? '') ?>">
                                <div class="field-feedback" id="course-feedback"></div>
                            </div>

                            <!-- DOB -->
                            <div class="col-md-6">
                                <label class="form-label-custom" for="dob">Date of Birth</label>
                                <input type="date" id="dob" name="dob" class="form-control-custom"
                                       value="<?= htmlspecialchars($_POST['dob'] ?? '') ?>">
                                <div class="field-feedback" id="dob-feedback"></div>
                            </div>

                            <!-- Photo -->
                            <div class="col-md-6">
                                <label class="form-label-custom" for="photo">Profile Photo</label>
                                <input type="file" id="photo" name="photo" class="form-control-custom"
                                       accept=".jpg,.jpeg,.png" style="padding:.5rem .75rem">
                                <div class="field-feedback" id="photo-feedback"></div>
                                <div class="mt-2">
                                    <img id="photoPreview" src="" alt="Preview"
                                         style="display:none;width:80px;height:80px;border-radius:12px;object-fit:cover;border:2px solid var(--border-color)">
                                </div>
                            </div>

                        </div>

                        <div class="mt-4 d-flex gap-3">
                            <button type="submit" class="btn-accent" id="submitBtn">
                                <i class="bi bi-person-plus"></i> Add Student
                            </button>
                            <a href="view_students.php" class="btn" style="background:rgba(255,255,255,0.06);color:var(--text-secondary);border:1px solid var(--border-color);border-radius:var(--radius-sm);padding:.6rem 1.5rem;font-size:.875rem;font-weight:600;text-decoration:none">
                                Cancel
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</main>

<footer class="site-footer">
    <p>© <?= date('Y') ?> Student Record Management System</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
// ── JS Form Validation ──
const RULES = {
    name:   { regex: /^[A-Za-z\s]{3,}$/,  msg: 'Name must be at least 3 letters (no numbers).' },
    email:  { regex: /^[^\s@]+@[^\s@]+\.[^\s@]+$/, msg: 'Enter a valid email address.' },
    phone:  { regex: /^\d{10}$/,           msg: 'Phone must be exactly 10 digits.' },
    course: { regex: /^.{2,}$/,            msg: 'Course name is required (min 2 chars).' },
};

function setFeedback(fieldId, type, msg) {
    const fb = document.getElementById(fieldId + '-feedback');
    const input = document.getElementById(fieldId);
    if (!fb) return;
    fb.className = 'field-feedback ' + type;
    if (type === 'success') {
        fb.innerHTML = '<i class="bi bi-check-circle-fill"></i> ' + msg;
        input.style.borderColor = 'var(--success)';
    } else if (type === 'error') {
        fb.innerHTML = '<i class="bi bi-x-circle-fill"></i> ' + msg;
        input.style.borderColor = 'var(--danger)';
    } else {
        fb.innerHTML = '';
        input.style.borderColor = '';
    }
}

// Validate individual regex fields on input
['name','email','phone','course'].forEach(id => {
    const el = document.getElementById(id);
    if (!el) return;
    el.addEventListener('input', () => {
        const val = el.value.trim();
        if (!val) { setFeedback(id, '', ''); return; }
        if (RULES[id].regex.test(val)) {
            setFeedback(id, 'success', 'Looks good!');
        } else {
            setFeedback(id, 'error', RULES[id].msg);
        }
    });
});

// DOB validation
document.getElementById('dob').addEventListener('change', function() {
    const val = this.value;
    if (!val) { setFeedback('dob','',''); return; }
    const selected = new Date(val);
    const today = new Date();
    today.setHours(0,0,0,0);
    if (selected > today) {
        setFeedback('dob','error','Date of birth cannot be in the future.');
    } else {
        setFeedback('dob','success','Valid date of birth.');
    }
});

// Photo preview + validation
document.getElementById('photo').addEventListener('change', function() {
    const file = this.files[0];
    const preview = document.getElementById('photoPreview');
    if (!file) { setFeedback('photo','',''); preview.style.display='none'; return; }
    const ext = file.name.split('.').pop().toLowerCase();
    if (!['jpg','jpeg','png'].includes(ext)) {
        setFeedback('photo','error','Only .jpg and .png files are allowed.');
        this.value = '';
        preview.style.display = 'none';
        return;
    }
    setFeedback('photo','success','Photo selected.');
    const reader = new FileReader();
    reader.onload = e => {
        preview.src = e.target.result;
        preview.style.display = 'block';
    };
    reader.readAsDataURL(file);
});

// Full form validation on submit
document.getElementById('addStudentForm').addEventListener('submit', function(e) {
    let valid = true;

    // Validate regex fields
    ['name','email','phone','course'].forEach(id => {
        const el = document.getElementById(id);
        const val = el.value.trim();
        if (!val || !RULES[id].regex.test(val)) {
            setFeedback(id, 'error', RULES[id].msg);
            valid = false;
        } else {
            setFeedback(id, 'success', 'Looks good!');
        }
    });

    // DOB
    const dobEl = document.getElementById('dob');
    if (!dobEl.value || new Date(dobEl.value) > new Date()) {
        setFeedback('dob','error','Date of birth cannot be empty or in the future.');
        valid = false;
    } else {
        setFeedback('dob','success','Valid date of birth.');
    }

    // Photo (optional but validate ext if provided)
    const photoEl = document.getElementById('photo');
    if (photoEl.files.length > 0) {
        const ext = photoEl.files[0].name.split('.').pop().toLowerCase();
        if (!['jpg','jpeg','png'].includes(ext)) {
            setFeedback('photo','error','Only .jpg and .png files allowed.');
            valid = false;
        }
    }

    if (!valid) e.preventDefault();
});
</script>
</body>
</html>

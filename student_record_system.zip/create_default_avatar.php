<?php
// ============================================
// create_default_avatar.php
// Run once to create a default.png placeholder
// ============================================
require_once 'config.php';

$img = imagecreatetruecolor(200, 200);
$bg  = imagecolorallocate($img, 28, 30, 39);
$fg  = imagecolorallocate($img, 99, 102, 241);
imagefilledrectangle($img, 0, 0, 200, 200, $bg);

// Draw circle
imagefilledellipse($img, 100, 80, 80, 80, $fg);
imagefilledellipse($img, 100, 190, 130, 80, $fg);

imagepng($img, UPLOAD_DIR . 'default.png');
imagedestroy($img);

echo "Default avatar created at " . UPLOAD_DIR . "default.png";
?>

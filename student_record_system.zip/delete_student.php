<?php
// ============================================
// delete_student.php - AJAX Delete Handler
// ============================================
require_once 'auth_check.php';
require_once 'config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
    exit;
}

$id = intval($_POST['id'] ?? 0);

if ($id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid student ID.']);
    exit;
}

// Get photo to delete file
$res = mysqli_query($conn, "SELECT photo FROM students WHERE id = $id");
$student = mysqli_fetch_assoc($res);

$stmt = mysqli_prepare($conn, "DELETE FROM students WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $id);

if (mysqli_stmt_execute($stmt) && mysqli_stmt_affected_rows($stmt) > 0) {
    // Delete photo file if not default
    if ($student && $student['photo'] && $student['photo'] !== 'default.png') {
        $photoPath = UPLOAD_DIR . $student['photo'];
        if (file_exists($photoPath)) unlink($photoPath);
    }
    echo json_encode(['success' => true, 'message' => 'Student deleted successfully.']);
} else {
    echo json_encode(['success' => false, 'message' => 'Student not found or already deleted.']);
}

mysqli_stmt_close($stmt);
?>

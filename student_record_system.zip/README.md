# 🎓 Student Record Management System

A full-stack PHP + MySQL student record system with a dark, modern UI.

---

## 📁 File Structure

```
student_record_system/
│
├── config.php                  # DB connection (edit credentials here)
├── auth_check.php              # Session guard — include at top of protected pages
│
├── login.php                   # Admin login page
├── logout.php                  # Session destroyer
│
├── index.php                   # Dashboard with stats
├── add_student.php             # Add student form + JS validation
├── view_students.php           # AJAX-powered student table
├── edit_student.php            # Edit student record
│
├── fetch_students.php          # API: returns all students as JSON
├── search_students.php         # API: live search → JSON
├── delete_student.php          # API: AJAX delete handler
│
├── style.css                   # External CSS (dark theme, animations)
├── database.sql                # Full database schema + sample data
├── create_default_avatar.php   # Utility: creates uploads/default.png
│
└── uploads/                    # Student photos (auto-created)
    └── default.png
```

---

## ⚙️ Setup Instructions

### 1. Requirements
- PHP 7.4+ (with GD extension for avatar generator)
- MySQL 5.7+ or MariaDB
- Web server: Apache (XAMPP/WAMP/LAMP) or Nginx
- A browser (Chrome / Firefox recommended)

### 2. Database Setup

**Option A — MySQL CLI:**
```bash
mysql -u root -p < database.sql
```

**Option B — phpMyAdmin:**
1. Open phpMyAdmin → click **Import**
2. Select `database.sql` → click **Go**

### 3. Configure Database Credentials

Edit `config.php`:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');       // ← your MySQL username
define('DB_PASS', '');           // ← your MySQL password
define('DB_NAME', 'student_db');
```

### 4. Place Files in Web Root

**XAMPP:** Copy the folder to `C:/xampp/htdocs/student_record_system/`

**LAMP/Ubuntu:** Copy to `/var/www/html/student_record_system/`

### 5. Set Uploads Folder Permissions (Linux/Mac)
```bash
chmod 755 uploads/
```

### 6. Generate Default Avatar (optional)
Visit: `http://localhost/student_record_system/create_default_avatar.php`

### 7. Login
Visit: `http://localhost/student_record_system/login.php`

| Field    | Value      |
|----------|------------|
| Username | `admin`    |
| Password | `admin123` |

---

## ✨ Features

| Feature | Implementation |
|---|---|
| Admin Login / Logout | PHP Sessions + bcrypt password |
| Session Protection | `auth_check.php` on all pages |
| Dashboard Stats | PHP + MySQL COUNT queries |
| Add Student | Form + server-side + JS validation |
| JS Validation | Regex for name/email/phone, DOB check, file type |
| Real-time Feedback | DOM inline error/success messages |
| Photo Upload | move_uploaded_file() → uploads/ folder |
| Prepared Statements | All DB ops use `mysqli_prepare()` |
| View Students | jQuery AJAX → JSON → DOM rendering |
| Live Search | keyup → AJAX → search_students.php |
| AJAX Delete | POST → delete_student.php → fadeOut row |
| Delete Confirmation | Bootstrap 5 Modal (no browser confirm()) |
| Edit Student | Pre-filled form, PHP update with prepared stmt |
| Column Sorting | JS Array.sort() with callback, Name & Course |
| Fade-in Effect | jQuery fadeIn() on table rows |
| Responsive Layout | Bootstrap 5 grid + mobile navbar |
| Custom Styling | CSS variables, card hover, page animation |

---

## 🔐 Security Notes

- All DB queries use **prepared statements** (no SQL injection)
- Passwords stored as **bcrypt hashes** via `password_hash()`
- File uploads validated for **extension** (jpg/png only) and **moved** out of tmp
- Sessions use `session_regenerate_id()` on login
- All user output wrapped in `htmlspecialchars()`

---

## 🎨 Tech Stack

- **Backend:** PHP 8, MySQLi
- **Frontend:** HTML5, CSS3, Bootstrap 5.3, Bootstrap Icons
- **JavaScript:** jQuery 3.7, vanilla JS
- **Database:** MySQL / MariaDB
- **Fonts:** Sora, Space Mono (Google Fonts)

---

## 📝 Default Admin

To add more admin users or change the password, generate a bcrypt hash:
```php
<?php echo password_hash('your_new_password', PASSWORD_BCRYPT); ?>
```
Then INSERT into `admin_users` table.

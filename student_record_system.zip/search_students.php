<?php
// ============================================
// search_students.php - Live Search API
// ============================================
require_once 'auth_check.php';
require_once 'config.php';

header('Content-Type: application/json');

$term = '%' . trim($_GET['q'] ?? '') . '%';

$stmt = mysqli_prepare($conn,
    "SELECT * FROM students
     WHERE name LIKE ? OR email LIKE ? OR phone LIKE ? OR course LIKE ?
     ORDER BY created_at DESC");
mysqli_stmt_bind_param($stmt, "ssss", $term, $term, $term, $term);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$students = [];
while ($row = mysqli_fetch_assoc($result)) {
    $students[] = [
        'id'     => $row['id'],
        'name'   => $row['name'],
        'email'  => $row['email'],
        'phone'  => $row['phone'],
        'course' => $row['course'],
        'dob'    => $row['dob'],
        'photo'  => $row['photo'] ?: 'default.png',
    ];
}
mysqli_stmt_close($stmt);

echo json_encode(['success' => true, 'data' => $students]);
?>

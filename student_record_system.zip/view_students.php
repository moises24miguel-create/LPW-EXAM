<?php
// ============================================
// view_students.php - AJAX-powered Student Table
// ============================================
require_once 'auth_check.php';
require_once 'config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Students — Student Record System</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<!-- Navbar -->
<header>
    <nav class="navbar navbar-expand-lg navbar-custom">
        <div class="container-fluid px-4">
            <a class="navbar-brand d-flex align-items-center" href="index.php">
                <span class="navbar-icon">🎓</span>
                <span class="navbar-brand-text">Student<span>RMS</span></span>
            </a>
            <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navMenu">
                <ul class="navbar-nav me-auto gap-1 ms-3">
                    <li class="nav-item"><a class="nav-link-custom" href="index.php"><i class="bi bi-grid-1x2"></i> Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link-custom active" href="view_students.php"><i class="bi bi-people"></i> Students</a></li>
                    <li class="nav-item"><a class="nav-link-custom" href="add_student.php"><i class="bi bi-person-plus"></i> Add Student</a></li>
                </ul>
                <a href="logout.php" class="btn-logout btn"><i class="bi bi-box-arrow-right me-1"></i>Logout</a>
            </div>
        </div>
    </nav>
</header>

<main>
<div class="page-wrapper main-content">
<div class="container-fluid px-4">

    <div class="page-header d-flex align-items-center justify-content-between">
        <div>
            <h1 class="page-title">All Students</h1>
            <p class="page-subtitle">Browse, search, and manage student records</p>
        </div>
        <a href="add_student.php" class="btn-accent">
            <i class="bi bi-plus-lg"></i> Add Student
        </a>
    </div>

    <!-- Alert placeholder -->
    <div id="alertBox"></div>

    <div class="content-card">
        <div class="card-header-custom">
            <span class="card-title-custom">
                <i class="bi bi-table" style="color:var(--accent-light)"></i>
                Student Records
                <span id="countBadge" style="background:rgba(99,102,241,0.15);color:var(--accent-light);border-radius:100px;padding:.1rem .55rem;font-size:.75rem;font-weight:600;margin-left:.3rem">...</span>
            </span>
            <!-- Live Search -->
            <div class="search-wrapper">
                <i class="bi bi-search"></i>
                <input type="text" id="searchInput" class="search-input" placeholder="Search students...">
            </div>
        </div>

        <div style="overflow-x:auto">
            <table class="table-custom" id="studentsTable">
                <thead>
                    <tr>
                        <th>S.No</th>
                        <th>Photo</th>
                        <th class="sortable" data-col="name">Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th class="sortable" data-col="course">Course</th>
                        <th>DOB</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="studentTableBody">
                    <tr>
                        <td colspan="8">
                            <div class="table-loading">
                                <div class="spinner-custom"></div>
                                Loading students...
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

</div>
</div>
</main>

<!-- ── Delete Confirmation Modal ── -->
<div class="modal fade" id="deleteModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="bi bi-exclamation-triangle-fill me-2" style="color:#fbbf24"></i>
                    Confirm Deletion
                </h5>
                <button type="button" class="btn-close-custom" data-bs-dismiss="modal">✕</button>
            </div>
            <div class="modal-body" style="padding:1.5rem;color:var(--text-secondary)">
                Are you sure you want to delete
                <strong id="deleteStudentName" style="color:var(--text-primary)"></strong>?
                <br><small style="color:var(--text-muted)">This action cannot be undone.</small>
            </div>
            <div class="modal-footer gap-2">
                <button type="button" class="btn" data-bs-dismiss="modal"
                        style="background:rgba(255,255,255,0.06);color:var(--text-secondary);border:1px solid var(--border-color);border-radius:var(--radius-sm);padding:.5rem 1.25rem;font-size:.875rem;font-weight:500">
                    Cancel
                </button>
                <button type="button" id="confirmDeleteBtn" class="btn-accent"
                        style="background:linear-gradient(135deg,#ef4444,#dc2626)">
                    <i class="bi bi-trash3"></i> Delete
                </button>
            </div>
        </div>
    </div>
</div>

<footer class="site-footer">
    <p>© <?= date('Y') ?> Student Record Management System</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script>
// ── State ──
let allStudents = [];
let sortState   = { col: null, dir: 'asc' };
let deleteId    = null;
const deleteModal = new bootstrap.Modal(document.getElementById('deleteModal'));

// ── Show Alert ──
function showAlert(type, msg) {
    const box = document.getElementById('alertBox');
    box.innerHTML = `<div class="alert-custom alert-${type}-custom mb-4">
        <i class="bi bi-${type === 'success' ? 'check-circle-fill' : 'exclamation-circle-fill'}"></i>
        ${msg}
    </div>`;
    setTimeout(() => $(box).find('.alert-custom').fadeOut(400, function(){ $(this).remove(); }), 3500);
}

// ── Format Date ──
function fmtDate(d) {
    if (!d) return '—';
    const dt = new Date(d);
    return dt.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}

// ── Render Table ──
function renderTable(students) {
    const tbody = document.getElementById('studentTableBody');
    document.getElementById('countBadge').textContent = students.length;

    if (!students.length) {
        tbody.innerHTML = `<tr><td colspan="8">
            <div class="empty-state">
                <div class="empty-state-icon">🔍</div>
                <p>No students found.</p>
            </div>
        </td></tr>`;
        return;
    }

    let html = '';
    students.forEach((s, i) => {
        const photo = s.photo ? `uploads/${s.photo}` : 'uploads/default.png';
        html += `<tr id="row-${s.id}" style="display:none">
            <td>${i + 1}</td>
            <td><img src="${photo}" alt="${s.name}" class="student-thumb"
                     onerror="this.src='https://ui-avatars.com/api/?name=${encodeURIComponent(s.name)}&background=6366f1&color=fff&size=80'"></td>
            <td class="student-name">${s.name}</td>
            <td><a href="mailto:${s.email}" style="color:var(--accent-light);text-decoration:none">${s.email}</a></td>
            <td>${s.phone}</td>
            <td><span class="badge-course">${s.course}</span></td>
            <td style="font-size:.8rem">${fmtDate(s.dob)}</td>
            <td>
                <div class="d-flex gap-1">
                    <a href="edit_student.php?id=${s.id}" class="btn-sm-icon btn-edit" title="Edit">
                        <i class="bi bi-pencil-fill"></i>
                    </a>
                    <button class="btn-sm-icon btn-delete" data-id="${s.id}" data-name="${s.name}" title="Delete">
                        <i class="bi bi-trash3-fill"></i>
                    </button>
                </div>
            </td>
        </tr>`;
    });

    tbody.innerHTML = html;

    // Fade in rows with stagger
    students.forEach((s, i) => {
        setTimeout(() => {
            $(`#row-${s.id}`).fadeIn(250);
        }, i * 40);
    });
}

// ── Load Students via AJAX ──
function loadStudents() {
    $.ajax({
        url: 'fetch_students.php',
        method: 'GET',
        dataType: 'json',
        success: function(res) {
            if (res.success) {
                allStudents = res.data;
                renderTable(allStudents);
            }
        },
        error: function() {
            document.getElementById('studentTableBody').innerHTML =
                '<tr><td colspan="8"><div class="empty-state"><p>Failed to load students.</p></div></td></tr>';
        }
    });
}

// ── Live Search ──
let searchTimer;
$('#searchInput').on('keyup input', function() {
    clearTimeout(searchTimer);
    const q = $(this).val().trim();

    if (!q) {
        renderTable(allStudents);
        return;
    }

    searchTimer = setTimeout(() => {
        $.ajax({
            url: 'search_students.php',
            method: 'GET',
            data: { q },
            dataType: 'json',
            success: function(res) {
                if (res.success) renderTable(res.data);
            }
        });
    }, 300);
});

// ── Column Sorting ──
$(document).on('click', '.sortable', function() {
    const col = $(this).data('col');

    if (sortState.col === col) {
        sortState.dir = sortState.dir === 'asc' ? 'desc' : 'asc';
    } else {
        sortState.col = col;
        sortState.dir = 'asc';
    }

    // Update header classes
    $('.sortable').removeClass('sort-asc sort-desc');
    $(this).addClass('sort-' + sortState.dir);

    const sorted = [...allStudents].sort((a, b) => {
        const va = (a[col] || '').toLowerCase();
        const vb = (b[col] || '').toLowerCase();
        if (va < vb) return sortState.dir === 'asc' ? -1 : 1;
        if (va > vb) return sortState.dir === 'asc' ? 1 : -1;
        return 0;
    });

    renderTable(sorted);
});

// ── AJAX Delete (Bootstrap Modal) ──
$(document).on('click', '.btn-delete', function() {
    deleteId = $(this).data('id');
    const name = $(this).data('name');
    document.getElementById('deleteStudentName').textContent = name;
    deleteModal.show();
});

$('#confirmDeleteBtn').on('click', function() {
    if (!deleteId) return;

    $.ajax({
        url: 'delete_student.php',
        method: 'POST',
        data: { id: deleteId },
        dataType: 'json',
        success: function(res) {
            deleteModal.hide();
            if (res.success) {
                $(`#row-${deleteId}`).fadeOut(400, function() {
                    $(this).remove();
                    // Remove from allStudents array
                    allStudents = allStudents.filter(s => s.id != deleteId);
                    document.getElementById('countBadge').textContent = allStudents.length;
                    showAlert('success', res.message);
                });
            } else {
                showAlert('danger', res.message);
            }
            deleteId = null;
        },
        error: function() {
            deleteModal.hide();
            showAlert('danger', 'An error occurred while deleting.');
            deleteId = null;
        }
    });
});

// ── Init ──
$(document).ready(function() {
    loadStudents();
});
</script>
</body>
</html>

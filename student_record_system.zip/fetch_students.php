<?php
// ============================================
// fetch_students.php - Returns JSON of all students
// Called via AJAX from view_students.php
// ============================================
require_once 'auth_check.php';
require_once 'config.php';

header('Content-Type: application/json');

$students = [];
$result = mysqli_query($conn, "SELECT * FROM students ORDER BY created_at DESC");

if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $students[] = [
            'id'         => $row['id'],
            'name'       => $row['name'],
            'email'      => $row['email'],
            'phone'      => $row['phone'],
            'course'     => $row['course'],
            'dob'        => $row['dob'],
            'photo'      => $row['photo'] ?: 'default.png',
            'created_at' => $row['created_at'],
        ];
    }
    echo json_encode(['success' => true, 'data' => $students]);
} else {
    echo json_encode(['success' => false, 'message' => 'DB error: ' . mysqli_error($conn)]);
}
?>

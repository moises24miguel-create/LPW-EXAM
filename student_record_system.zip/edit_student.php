<?php
// ============================================
// edit_student.php - Edit Student Record
// ============================================
require_once 'auth_check.php';
require_once 'config.php';

$id = intval($_GET['id'] ?? 0);
$error = '';
$success = '';

if ($id <= 0) {
    header("Location: view_students.php");
    exit;
}

// Fetch existing data
$stmt = mysqli_prepare($conn, "SELECT * FROM students WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$student = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);

if (!$student) {
    header("Location: view_students.php");
    exit;
}

// Handle update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name   = trim($_POST['name']   ?? '');
    $email  = trim($_POST['email']  ?? '');
    $phone  = trim($_POST['phone']  ?? '');
    $course = trim($_POST['course'] ?? '');
    $dob    = $_POST['dob'] ?? '';
    $errors = [];

    if (!preg_match('/^[A-Za-z\s]{3,}$/', $name))
        $errors[] = "Invalid name.";
    if (!filter_var($email, FILTER_VALIDATE_EMAIL))
        $errors[] = "Invalid email.";
    if (!preg_match('/^\d{10}$/', $phone))
        $errors[] = "Phone must be 10 digits.";
    if (empty($course))
        $errors[] = "Course is required.";
    if (empty($dob) || strtotime($dob) > time())
        $errors[] = "Date of birth cannot be in the future.";

    $photo_name = $student['photo'];

    if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
        $ext = strtolower(pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, ['jpg','jpeg','png'])) {
            $errors[] = "Photo must be .jpg or .png.";
        } else {
            $new_photo = uniqid('stu_', true) . '.' . $ext;
            $dest = UPLOAD_DIR . $new_photo;
            if (move_uploaded_file($_FILES['photo']['tmp_name'], $dest)) {
                // Delete old photo
                if ($photo_name && $photo_name !== 'default.png' && file_exists(UPLOAD_DIR . $photo_name)) {
                    unlink(UPLOAD_DIR . $photo_name);
                }
                $photo_name = $new_photo;
            } else {
                $errors[] = "Photo upload failed.";
            }
        }
    }

    if (empty($errors)) {
        $upd = mysqli_prepare($conn,
            "UPDATE students SET name=?, email=?, phone=?, course=?, dob=?, photo=? WHERE id=?");
        mysqli_stmt_bind_param($upd, "ssssssi", $name, $email, $phone, $course, $dob, $photo_name, $id);
        if (mysqli_stmt_execute($upd)) {
            $success = "Student record updated successfully!";
            // Refresh student data
            $student = array_merge($student, compact('name','email','phone','course','dob') + ['photo' => $photo_name]);
        } else {
            if (mysqli_errno($conn) == 1062) {
                $error = "A student with that email already exists.";
            } else {
                $error = "Database error: " . mysqli_error($conn);
            }
        }
        mysqli_stmt_close($upd);
    } else {
        $error = implode('<br>', $errors);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Student — Student Record System</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<!-- Navbar -->
<header>
    <nav class="navbar navbar-expand-lg navbar-custom">
        <div class="container-fluid px-4">
            <a class="navbar-brand d-flex align-items-center" href="index.php">
                <span class="navbar-icon">🎓</span>
                <span class="navbar-brand-text">Student<span>RMS</span></span>
            </a>
            <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navMenu">
                <ul class="navbar-nav me-auto gap-1 ms-3">
                    <li class="nav-item"><a class="nav-link-custom" href="index.php"><i class="bi bi-grid-1x2"></i> Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link-custom" href="view_students.php"><i class="bi bi-people"></i> Students</a></li>
                    <li class="nav-item"><a class="nav-link-custom" href="add_student.php"><i class="bi bi-person-plus"></i> Add Student</a></li>
                </ul>
                <a href="logout.php" class="btn-logout btn"><i class="bi bi-box-arrow-right me-1"></i>Logout</a>
            </div>
        </div>
    </nav>
</header>

<main>
<div class="page-wrapper main-content">
<div class="container-fluid px-4">

    <div class="page-header d-flex align-items-center gap-3">
        <a href="view_students.php" class="btn-sm-icon btn-edit" style="width:36px;height:36px" title="Back">
            <i class="bi bi-arrow-left"></i>
        </a>
        <div>
            <h1 class="page-title">Edit Student</h1>
            <p class="page-subtitle">Updating record for <strong style="color:var(--accent-light)"><?= htmlspecialchars($student['name']) ?></strong></p>
        </div>
    </div>

    <?php if ($success): ?>
    <div class="alert-custom alert-success-custom mb-4">
        <i class="bi bi-check-circle-fill"></i> <?= $success ?>
        <a href="view_students.php" class="ms-2" style="color:inherit;text-decoration:underline">Back to Students</a>
    </div>
    <?php endif; ?>
    <?php if ($error): ?>
    <div class="alert-custom alert-danger-custom mb-4">
        <i class="bi bi-exclamation-circle-fill"></i> <?= $error ?>
    </div>
    <?php endif; ?>

    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="content-card">
                <div class="card-header-custom">
                    <span class="card-title-custom">
                        <i class="bi bi-pencil-square" style="color:var(--accent-light)"></i>
                        Edit Information
                    </span>
                    <!-- Current Photo -->
                    <div class="d-flex align-items-center gap-2">
                        <img id="currentPhoto"
                             src="<?= htmlspecialchars(UPLOAD_URL . ($student['photo'] ?: 'default.png')) ?>"
                             alt=""
                             onerror="this.src='https://ui-avatars.com/api/?name=<?= urlencode($student['name']) ?>&background=6366f1&color=fff&size=80'"
                             style="width:44px;height:44px;border-radius:10px;object-fit:cover;border:2px solid var(--border-color)">
                        <span style="color:var(--text-muted);font-size:.8rem">Current Photo</span>
                    </div>
                </div>
                <div class="card-body-custom">
                    <form id="editForm" method="POST" action="edit_student.php?id=<?= $id ?>"
                          enctype="multipart/form-data" novalidate>
                        <div class="row g-4">

                            <div class="col-md-6">
                                <label class="form-label-custom">Full Name</label>
                                <input type="text" id="name" name="name" class="form-control-custom"
                                       value="<?= htmlspecialchars($student['name']) ?>">
                                <div class="field-feedback" id="name-feedback"></div>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label-custom">Email Address</label>
                                <input type="email" id="email" name="email" class="form-control-custom"
                                       value="<?= htmlspecialchars($student['email']) ?>">
                                <div class="field-feedback" id="email-feedback"></div>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label-custom">Phone Number</label>
                                <input type="tel" id="phone" name="phone" class="form-control-custom"
                                       value="<?= htmlspecialchars($student['phone']) ?>">
                                <div class="field-feedback" id="phone-feedback"></div>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label-custom">Course</label>
                                <input type="text" id="course" name="course" class="form-control-custom"
                                       value="<?= htmlspecialchars($student['course']) ?>">
                                <div class="field-feedback" id="course-feedback"></div>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label-custom">Date of Birth</label>
                                <input type="date" id="dob" name="dob" class="form-control-custom"
                                       value="<?= htmlspecialchars($student['dob']) ?>">
                                <div class="field-feedback" id="dob-feedback"></div>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label-custom">Change Photo (optional)</label>
                                <input type="file" id="photo" name="photo" class="form-control-custom"
                                       accept=".jpg,.jpeg,.png" style="padding:.5rem .75rem">
                                <div class="field-feedback" id="photo-feedback"></div>
                            </div>

                        </div>

                        <div class="mt-4 d-flex gap-3">
                            <button type="submit" class="btn-accent">
                                <i class="bi bi-floppy"></i> Save Changes
                            </button>
                            <a href="view_students.php" class="btn"
                               style="background:rgba(255,255,255,0.06);color:var(--text-secondary);border:1px solid var(--border-color);border-radius:var(--radius-sm);padding:.6rem 1.5rem;font-size:.875rem;font-weight:600;text-decoration:none">
                                Cancel
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</main>

<footer class="site-footer">
    <p>© <?= date('Y') ?> Student Record Management System</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Reuse same validation from add_student
const RULES = {
    name:   { regex: /^[A-Za-z\s]{3,}$/,  msg: 'Name must be at least 3 letters (no numbers).' },
    email:  { regex: /^[^\s@]+@[^\s@]+\.[^\s@]+$/, msg: 'Enter a valid email address.' },
    phone:  { regex: /^\d{10}$/,           msg: 'Phone must be exactly 10 digits.' },
    course: { regex: /^.{2,}$/,            msg: 'Course name is required (min 2 chars).' },
};

function setFeedback(fieldId, type, msg) {
    const fb    = document.getElementById(fieldId + '-feedback');
    const input = document.getElementById(fieldId);
    if (!fb) return;
    fb.className = 'field-feedback ' + type;
    if (type === 'success') {
        fb.innerHTML = '<i class="bi bi-check-circle-fill"></i> ' + msg;
        input.style.borderColor = 'var(--success)';
    } else if (type === 'error') {
        fb.innerHTML = '<i class="bi bi-x-circle-fill"></i> ' + msg;
        input.style.borderColor = 'var(--danger)';
    } else {
        fb.innerHTML = '';
        input.style.borderColor = '';
    }
}

['name','email','phone','course'].forEach(id => {
    const el = document.getElementById(id);
    if (!el) return;
    el.addEventListener('input', () => {
        const val = el.value.trim();
        if (!val) { setFeedback(id,'',''); return; }
        RULES[id].regex.test(val)
            ? setFeedback(id,'success','Looks good!')
            : setFeedback(id,'error', RULES[id].msg);
    });
});

document.getElementById('dob').addEventListener('change', function() {
    if (!this.value) { setFeedback('dob','',''); return; }
    new Date(this.value) > new Date()
        ? setFeedback('dob','error','DOB cannot be in the future.')
        : setFeedback('dob','success','Valid date.');
});

document.getElementById('photo').addEventListener('change', function() {
    if (!this.files.length) return;
    const ext = this.files[0].name.split('.').pop().toLowerCase();
    if (!['jpg','jpeg','png'].includes(ext)) {
        setFeedback('photo','error','Only .jpg and .png allowed.');
        this.value = '';
        return;
    }
    setFeedback('photo','success','Photo selected.');
    // Preview
    const reader = new FileReader();
    reader.onload = e => document.getElementById('currentPhoto').src = e.target.result;
    reader.readAsDataURL(this.files[0]);
});

document.getElementById('editForm').addEventListener('submit', function(e) {
    let valid = true;
    ['name','email','phone','course'].forEach(id => {
        const el = document.getElementById(id);
        const val = el.value.trim();
        if (!val || !RULES[id].regex.test(val)) {
            setFeedback(id,'error',RULES[id].msg); valid = false;
        } else {
            setFeedback(id,'success','Looks good!');
        }
    });
    const dobEl = document.getElementById('dob');
    if (!dobEl.value || new Date(dobEl.value) > new Date()) {
        setFeedback('dob','error','DOB cannot be empty or future.'); valid = false;
    }
    if (!valid) e.preventDefault();
});
</script>
</body>
</html>

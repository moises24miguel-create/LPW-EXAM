-- ============================================
-- Student Record System - Database Setup
-- ============================================

CREATE DATABASE IF NOT EXISTS student_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE student_db;

-- Students table
CREATE TABLE IF NOT EXISTS students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    phone VARCHAR(15) NOT NULL,
    course VARCHAR(100) NOT NULL,
    dob DATE NOT NULL,
    photo VARCHAR(255) DEFAULT 'default.png',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Admin users table
CREATE TABLE IF NOT EXISTS admin_users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
) ENGINE=InnoDB;

-- Insert default admin: username=admin, password=admin123 (bcrypt hashed)
-- Password hash for 'admin123'
INSERT INTO admin_users (username, password) VALUES
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');

-- Sample students data (optional)
INSERT INTO students (name, email, phone, course, dob, photo) VALUES
('Arjun Sharma', 'arjun.sharma@example.com', '9876543210', 'Computer Science', '2002-05-15', 'default.png'),
('Priya Patel', 'priya.patel@example.com', '8765432109', 'Electronics Engineering', '2003-08-22', 'default.png'),
('Rahul Mehta', 'rahul.mehta@example.com', '7654321098', 'Mechanical Engineering', '2001-12-10', 'default.png');
